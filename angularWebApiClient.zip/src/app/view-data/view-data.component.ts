import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CrudClientService } from '../crud-client.service';
import { DbModel } from '../db-model';

@Component({
  selector: 'app-view-data',
  templateUrl: './view-data.component.html',
  styleUrls: ['./view-data.component.css']
})
export class ViewDataComponent implements OnInit {

addForm: FormGroup; 
data : DbModel[];
id_NextValue:number;
editRowID :any='';
constructor(private formBuilder: FormBuilder, private crudClientService : CrudClientService ) { }
editMode :boolean;
ngOnInit() {
  this.addForm = this.formBuilder.group({  
    id:[],
    datavalue : []
  });  
  this.editMode=false;
   
    this.crudClientService.getData()
    .subscribe(  
      res => { 
    //    console.log("data is " + JSON.stringify(data));
        this.data = res ; 
  this.id_NextValue=res.length+1;
              },
             err => console.error(err), 
             () => console.log('Client completed') 
             
  );


  
  }

  onSubmit(){
    this.crudClientService.createData(this.addForm.value)  
      .subscribe(data => {  
       
        console.log(data); 
        // var i = setTimeout(() =>  this.router.navigate(['/role/viewrole']) , 3000); 
      
      },  
      error => {   
        console.log(JSON.stringify(error));  
      });  
}
edit(id:number){
  this.editMode=true;
  this.editRowID =id;
  this.addForm.controls["datavalue"].setValue("");
}
editData(id:number){
  this.editRowID = id;  
  this.editMode=true;
  console.log(JSON.stringify(this.addForm.value));
  this.addForm.controls["id"].setValue(id);
  this.crudClientService.updateData(this.addForm.value)  
  .subscribe(data => {  
   
    console.log(data); 
    // var i = setTimeout(() =>  this.router.navigate(['/role/viewrole']) , 3000); 
  
  },  
  error => {   
    console.log(JSON.stringify(error));  
  });  

}
Cancel(){
  this.editMode=false; 
  this.editRowID = '';  
  console.log(JSON.stringify(this.addForm.value));
}


deleteData(id:number){
  this.addForm.controls["id"].setValue(id);
  this.crudClientService.deleteData(this.addForm.value)  
  .subscribe(data => {
   
    console.log(data); 
    // var i = setTimeout(() =>  this.router.navigate(['/role/viewrole']) , 3000); 
  
  },  
  error => {   
    console.log(JSON.stringify(error));  
  });  
  console.log(id);
}


}
