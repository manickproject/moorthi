import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewDataComponent } from './view-data/view-data.component';


const routes: Routes = [
  { path: "", redirectTo: "view", pathMatch: "full" },
  { path: "view", component: ViewDataComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
