import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http'; 
import { from, Observable } from 'rxjs'; 
import { tap, catchError } from 'rxjs/operators';
import {DbModel} from "./db-model"
import { Response  as ServiceResponse} from './Response';

@Injectable({
  providedIn: 'root'
})
export class CrudClientService {

 
  API_URL_BASE = "http://localhost:59222/api/Data"; 
  constructor(private http: HttpClient) { }  
   // baseUrl: string = 'http://localhost:59222/api/Data';
     

    getData() : Observable<DbModel[]> {  
      return this.http.get<DbModel[]>(this.API_URL_BASE).pipe(
        tap(data => 
    //console.log('Data fetched:'+JSON.stringify(data))
    console.log('Data fetched')
    )
    ,
        catchError(this.handleError));
          
    }
  
  private handleError(err:HttpErrorResponse) {
        let errMsg:string='';
        console.log(err);
        if (err.error instanceof Error) {
           // A client-side or network error occurred. Handle it accordingly.
           console.log('An error occurred:', err.error.message);
            errMsg=err.error.message;} 
          
           else {
           // The backend returned an unsuccessful response code.
           // The response body may contain clues as to what went wrong,
           console.log(`Backend returned code ${err.status}`);
              errMsg=err.error.status;
         }
            return Observable.throw(errMsg); 
      }

    createData(dbModel: DbModel):Observable<ServiceResponse> {  
      console.log("Before Create " + JSON.stringify(dbModel)); 

      dbModel.id=0;
  
     console.log("After Create " + JSON.stringify(dbModel));

      return this.http.post<ServiceResponse>(this.API_URL_BASE, dbModel).pipe(
               tap(data => console.log('Create Role - Response :'+JSON.stringify(data))),
                   catchError(this.handleError)) ;  
            
    }  

    updateData(dbModel: DbModel):Observable<ServiceResponse> {  
 
      let id = dbModel.id;
      //dbModel.id= 0;
    
      console.log(JSON.stringify(dbModel));
       return this.http.put<ServiceResponse>(this.API_URL_BASE + '/' + id, dbModel).pipe(
              tap(data => console.log('update data - Response :'+JSON.stringify(data))),
                  catchError(this.handleError)) ; ;  
    }


    deleteData(dbModel: DbModel):Observable<ServiceResponse> {  
 
      let id = dbModel.id;
      //dbModel.id= 0;
    
      console.log(JSON.stringify(dbModel));
       return this.http.delete<ServiceResponse>(this.API_URL_BASE + '/' + id).pipe(
              tap(data => console.log('delete data - Response :'+JSON.stringify(data))),
                  catchError(this.handleError)) ; ;  
    }
  
}
