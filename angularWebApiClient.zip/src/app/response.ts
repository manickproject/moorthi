export class Response {
    code : number; 
    message  :string;
    result   :string;
    
}
