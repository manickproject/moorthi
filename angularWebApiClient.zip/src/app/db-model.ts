export class DbModel {
    public id : number;
    public  dataValue :string;
   

}
