import { TestBed } from '@angular/core/testing';

import { CrudClientService } from './crud-client.service';

describe('CrudClientService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CrudClientService = TestBed.get(CrudClientService);
    expect(service).toBeTruthy();
  });
});
