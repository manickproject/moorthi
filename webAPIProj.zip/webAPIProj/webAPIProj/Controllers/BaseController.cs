﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using webAPIProj.Model;

namespace webAPIProj.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public abstract class BaseController : ControllerBase
    {
        protected ServiceResponse<T> BuildServiceResponse<T>(T value, string message, ServiceCode code, string token = "")
        {
            return new ServiceResponse<T>
            {
                Code = code,
                Message = message,
                Result = value                
            };
        }
    }
}