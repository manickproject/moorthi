﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using webAPIProj.Model;

namespace webAPIProj.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DataController : BaseController
    {
        // [ProducesResponseType(404)]
        // [ProducesResponseType(200, Type = typeof(IEnumerable<string>))]
        // [HttpGet(Name = "GetData")]
        [HttpGet]
        public IActionResult  Get()
         {
            data d = new data();
            List<data> lstD = new List<data>();
            lstD.Add(new data { id = 1, dataValue = "Value 1" });
            lstD.Add(new data { id = 2, dataValue = "Value 2" });
            lstD.Add(new data { id = 3, dataValue = "Value 3" });
            return Ok(lstD);
        }

        // GET: api/Data/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Data
        [HttpPost]
        public IActionResult Post([FromBody] data value)
        {
            return Ok(BuildServiceResponse(value, value.Equals("") ? "Failure":"Success", value.Equals("")? ServiceCode.Failure : ServiceCode.Success));
        }

        // PUT: api/Data/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] data value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
